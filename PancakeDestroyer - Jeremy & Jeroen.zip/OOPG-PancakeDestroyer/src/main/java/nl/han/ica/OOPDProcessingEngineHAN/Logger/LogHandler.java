package nl.han.ica.OOPDProcessingEngineHAN.Logger;

/**
 * Indicates the log handler.
 */
public interface LogHandler {
	
    public void logln(int level, String message);
}
